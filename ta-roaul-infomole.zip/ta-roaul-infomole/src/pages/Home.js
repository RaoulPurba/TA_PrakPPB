import React from 'react'

export default function Home() {
  return (
    <div className="home" id="home">
      <h1>Welcome to</h1>
      <h1>Mobile Legends: Bang Bang Guide</h1>
      <h2>By Raoul Habonaran</h2>
    </div>
  )
}
