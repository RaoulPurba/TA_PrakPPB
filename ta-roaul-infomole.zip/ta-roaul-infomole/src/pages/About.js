import React from 'react'
import "../App.css";


export default function About() {
  return (
    <div className="about">
      <div className="about-app">
        <h1>About Page</h1>
        <p>
          Tugas Akhir Praktikum Pemrograman Perangkat Bergerak.
        </p>
      </div>
      <div className="about-me">
        <h2>About me:</h2>
        <img className="imageStyle" src="/raoul.jpg" alt="foto-raoul" />
        <p>Nama: Raoul Habonaran</p>
        <p>NIM: 21120121130053</p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
        <p></p>
      </div>
    </div>
  )
}
